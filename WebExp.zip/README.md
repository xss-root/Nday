# 项目宗旨
近1年的web exploit收集整理，方便直接利用
