# 0x00 复现环境
使用复现环境：360众测仿真实战靶场考试  
其他复现环境：https://github.com/vulhub/vulhub/tree/master/jupyter/notebook-rce

# 0x01 利用条件
无

# 0x02 影响版本
全版本（只要管理员没有为web界面访问配置密码、ip限制等策略，都受影响）

# 0x03 漏洞复现
由于考试时没有截图，故下图借用别人的图

新建一个terminal窗口，如图  
![image](./0.png)  
直接就RCE了，如图  
![image](./1.png)

# 0x04 踩坑记录
无

# 参考链接
https://www.cnblogs.com/mke2fs/p/12718499.html
